=== Ingot: Give ===
Contributors: Shelob9
Requires at least: 4.4.0
Tested up to: 4.5
Stable tag: 1.0.0
License: GPL v2+

Give support for Ingot: A/B testing made easy for WordPress - Do less, convert more.

== Changelog ==
= 1.0.0 =
* Inital release as add-on

